<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Dog;
use App\Breed;
use validator;

class MovieController extends Controller
{
    //
    public function showDogs()
    {
        
        $dogs = Dog::All();
        return view('dogs.show', compact('dogs'));
    }

    public function createDogs()
    {
        
        $breeds = Breed::All();
        return view('dogs.createDog', compact('breeds'));

    }


    public function store(Request $request)
    {
        $validator = validator::make(($request->all), [
            'name' => 'required|max:50|string',
            'sex' => 'required|max:10|string',
            'age' => 'required|integer|number',
            'weight' => 'required|integer|number',
            'height' => 'required|number',
            'breed' => 'required|integer'
        ]);

            if ($validator->fails()){
                return redirect('createDog')
                    ->withErrors($validator)
                    ->withInput();

            }else{
                    $dogs = new Dog([
                    "name" => $request->name,
                    "sex" => $request->sex,
                    "age" => $request->age,
                    "weight" => $request->weight,
                    "height" => $request->height,
                    "breed" => $request->breed_id
                ]);
        
            $dogs->save();

            return redirect('/dogs');

        };

    public function edit($id)
    {
    
        
        $dogs = Dog::find($id);
        $breeds = Breed::All();

        return view ('dogs.edit', compact ('dog', 'breeds'));
    }

    public function update(Request $request, $id)
    {
        $dogs = Dog::find($id);
        


        $dogs->name=$request->name;
        $dogs->sex=$request->sex;
        $dogs->age=$request->age;
        $dogs->weight=$request->weight;
        $dogs->height=$request->height;
        $dogs->breed_id=$request->breed_id;

        $dogs->save();

        return redirect('/dogs');
        
    }

    public function delete($id)
    {
        $dog = Dog::find($id);
        

        $dog->delete();
        
        return redirect('/dogs');
        
    }
}
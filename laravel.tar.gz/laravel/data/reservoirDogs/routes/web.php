<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


//Quand l'utlisateur va taper /animals, on retournera la vue animals
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/dogs', 'DogController@showDogs')->name('dogs');

// Si l'utilisateur n'est pas connecté il ne pourra avoir accès aux pages comprises après
Route::group(['middleware' => ['auth']], function(){

Route::get('/createDog', 'DogController@createDogs')->name('createDog');


Route::post('/storeDog', 'DogController@store')->name('storeDog');
Route::post('/editDog/{id}', 'DogController@edit')->name('editDog');

Route::post('/updateDog/{id}', 'DogController@update')->name('updateDog');
Route::post('/deleteDog{id}', 'DogController@delete')->name('deleteDog');



});
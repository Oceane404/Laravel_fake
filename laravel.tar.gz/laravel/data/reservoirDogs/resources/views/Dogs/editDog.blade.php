@extends('template')

@section('content2')


<h1 style="text-align:center">Edition animal</h1>

<form id ="form" action="{{route('updateDog', $dog->id)}}"" method="POST">
    @csrf
    <div class="form-group">
        <label for="name">Nom</label>
        <input type="text" class="form-control" id="name" name="name" value="{{$dog->name}}" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <div class="form-group">
        <label for="sex">Sexe</label>
        <input type="text" class="form-control" id="sexe" name="sex" value="{{$dog->sex}}" aria-describedby="emailHelp" placeholder="Enter sex">
    </div>
    <div class="form-group">
        <label for="age">Age</label>
        <input type="text" class="form-control" id="age" name= "age" value="{{$dog->age}}" aria-describedby="emailHelp" placeholder="Enter age">
    </div>
    <div class="form-group">
        <label for="weight">Poids</label>
        <input type="text" class="form-control" id="weight" name="weight" value="{{$dog->weight}}" aria-describedby="emailHelp" placeholder="Enter weight">
    </div>
    <div class="form-group">
        <label for="height">Taille</label>
        <input type="text" class="form-control" id="height" name="height" value="{{$dog->height}}" aria-describedby="emailHelp" placeholder="Enter height">
    </div>
  
    
    
    <div id="form">
        <label for="breed">Breed</label>
        <select name="breed_id">
            @foreach ($breeds as $breed)
                @if($breed-> name == $dog->name)
                @else
                  <option selected="selected" value="{{$breed->id}}">{{$breed->name}}</option>
                @endif
                  <option value="{{$breed->id}}">{{$breed->name}}</option>
            @endforeach
        </select>
    
    </div>
    <button type="submit" class="btn btn-primary">Modifier</button>
</form>

@endsection


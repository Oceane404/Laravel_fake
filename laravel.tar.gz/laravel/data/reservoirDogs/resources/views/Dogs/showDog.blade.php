@extends('template')

@section('content2')


  
        <table class="table">
                <thead class="thead-dark">
                  <tr>
                    <th scope="col">name</th>
                    <th scope="col">sexe</th>
                    <th scope="col">taille</th>
                    <th scope="col">poids</th>
                    <th scope="col">âge</th>
                    <th scope="col">race</th>
                    @if(Auth::check())
                        @if(Auth::user()->role == 'administrator')
                            <th scope="col">Modifier</th>
                            <th scope="col">Supprimer</th>
                        @endif
                    @endif    
                  </tr>
                </thead>
                <tbody>
            @foreach($dogs as $dog)
                  <tr>
                    <td style="text-align-center">{{$dog->name}}</td>
                    <td style="text-align-center">{{$dog->sexe}}</td>
                    <td style="text-align-center">{{$dog->taille}}</td>
                    <td style="text-align-center">{{$dog->poids}}</td>
                    <td style="text-align-center">{{$dog->age}}</td>
                    <td style="text-align-center">{{$dog->race}}</td>
                    <td style="text-align-center">{{$dog->breed->name}}</td>
                    <td style="text-align-center" class="table-warning">
                    <form action ="{{route('editDog', $dog->id)}}" method="POST">
                        @csrf
                        
                    @if(Auth::check())
                        @if(Auth::user()->role == 'administrator')
                        <button type="submit" class="btn btn-primary">Modifier</button>
                    </td>
                    </form>
                        <td class="table-warning" ">
                    <form action ="{{route('deleteDog', $dog->id)}}" method="POST">
                        @csrf
                            <button type="submit" class="btn btn-primary">Supprimer</button>
                    @endif
                    </form>
                    @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
@endsection
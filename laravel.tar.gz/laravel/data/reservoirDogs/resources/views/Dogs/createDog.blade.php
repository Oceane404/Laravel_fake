@extends('template')

@section('content2')


<h1 style="text-align:center">Page d'ajout de nouveaux chiens</h1>


<form id="form" action="storeDog" method="POST">
    @csrf
    <div class="form-group">
        <label for="name">Nom</label>
        <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter name">
    </div>
    <div class="form-group">
        <label for="sex">Sexe</label>
        <input type="text" class="form-control" id="sexe" name="sex" aria-describedby="emailHelp" placeholder="Enter sex">
    </div>
    <div class="form-group">
        <label for="age">Age</label>
        <input type="text" class="form-control" id="age" name= "age" aria-describedby="emailHelp" placeholder="Enter age">
    </div>
    <div class="form-group">
        <label for="weight">Poids</label>
        <input type="text" class="form-control" id="poids" name="weight" aria-describedby="emailHelp" placeholder="Enter weight">
    </div>
    
    <div class="form-group">
        <label for="height">Taille</label>
        <input type="text" class="form-control" id="taille" name="height" aria-describedby="emailHelp" placeholder="Enter height">
    </div>


    <div id="form">
        <label for="breed">Race</label>
        <select name="breed_id">
            @foreach ($breeds as $breed)
                <option value="{{$breed->id}}">{{$breed->name}}</option>
            @endforeach
        </select>
    
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
    @else

</form>



@endsection


<?php

use Illuminate\Database\Seeder;

class BreedTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('breeds')->insert([
            'name' => 'Teckel',
        ]);
        DB::table('breeds')->insert([
            'name' => 'Berger allemand',
        ]);

        DB::table('breeds')->insert([
            'name' => 'Beagle',
        ]);

        DB::table('breeds')->insert([
            'name' => 'Scottish terrier',
        ]);

        DB::table('breeds')->insert([
            'name' => 'Golden retriever',
        ]);
    }
}

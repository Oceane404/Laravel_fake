<?php

use Illuminate\Database\Seeder;

class BreedTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('breeds')->insert([
            'name_id' => 1,
            'classification' => 'poils courts',
            'esperance' => 11,
           

        ]);

        DB::table('breeds')->insert([
            'name_id' => 2,
            'classification' => 'poils courts',
            'esperance' => 15,
        ]);

        DB::table('dogs')->insert([
            'name_id' => 3,
            'classification' => 'poils longs',
            'esperance' => 13,

        ]);

        
    }
}

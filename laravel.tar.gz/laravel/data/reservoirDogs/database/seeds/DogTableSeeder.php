<?php

use Illuminate\Database\Seeder;

class DogTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('dogs')->insert([
            'name' => 'cook',
            'sex' => 'male',
            'age' => 10,
            'poids' => 15,
            'taille' => 105,
            'breed_id' => 1

        ]);

        DB::table('dogs')->insert([
            'name' => 'Bobby',
            'sex' => 'male',
            'age' => 5,
            'poids' => 9,
            'taille' => 75,
            'breed_id' => 3
        ]);

        DB::table('dogs')->insert([
            'name' => 'Christiane',
            'sex' => 'female',
            'age' => 2,
            'poids' => 9,
            'taille' => 100,
            'breed_id' => 2

        ]);

        
    }
}
